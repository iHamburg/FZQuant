/**
 * Created by macos on 16/9/29.
 */

// MySQL数据库联接配置
module.exports = {

  host: '121.42.26.144', //不能用localhost
  username: 'root',
  password: 'root',
  database: 'fzquant',
        // port: 3306
};
