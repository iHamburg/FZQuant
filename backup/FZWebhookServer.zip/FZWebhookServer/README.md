# cloudmerchant server

npm install

npm start


测试接口：
http://localhost:3000/api/tests/axios